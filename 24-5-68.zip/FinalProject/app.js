const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const multer = require('multer');
const path = require('path');
const { Pool } = require('pg');
const app = express();

let publicList = [];

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');



app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use(session({
    secret: 'mySecretKey',
    resave: false,
    saveUninitialized: true,
}));


const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'reserve_fruit',
    password: '1',
    port: 5432,
});

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'public/uploads'); 
    },
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname);
      const name = Date.now() + ext;
      cb(null, name);
    }
  });

  const upload = multer({ storage });

app.get('/', (req, res) => {
    res.render('index');
});

app.get('/showFruit', async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT fruit_id, fruit_name, image_path, quantity FROM fruit`
        );

        res.render('showFruit', { fruit: result.rows });

    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});

app.get('/insertFruit', (req, res) => {
    res.render('insertFruit');
});

app.post('/insertFruit', upload.single('image_path'), async (req, res) => {
    try {
      const { fruit_name, quantity } = req.body;
      const imageFile = req.file ? '/uploads/' + req.file.filename : null;
  
      await pool.query(
        `INSERT INTO fruit (fruit_name, image_path, quantity)
         VALUES ($1, $2, $3)`,
        [fruit_name, imageFile, quantity]
      );
  
      res.redirect('/showFruit');
    } catch (err) {
      console.error(err);
      res.status(500).send('Server Error');
    }
  });

  app.get('/multiplyFruit', (req, res) => {
    const { fruit_id, fruit_name, quantity } = req.query;
    res.render('multiplyFruit', { fruit_id, fruit_name, quantity });
});

app.post('/multiplyQuantity', async (req, res) => {
    const { fruit_id, quantity } = req.body;
    const quantityToAdd = parseInt(quantity);

    try {
        const result = await pool.query('SELECT quantity FROM fruit WHERE fruit_id = $1', [fruit_id]);

        if (result.rows.length === 0) {
            return res.status(404).send("ไม่พบข้อมูลผลไม้");
        }

        const currentQuantity = result.rows[0].quantity;
        const newQuantity = currentQuantity + quantityToAdd;

        await pool.query('UPDATE fruit SET quantity = $1 WHERE fruit_id = $2', [newQuantity, fruit_id]);

        res.redirect('/showFruit'); 
    } catch (err) {
        console.error(err);
        res.status(500).send("เกิดข้อผิดพลาดในการอัปเดต");
    }
});

app.get('/cutbackFruit', (req, res) => {
    const { fruit_id, fruit_name, quantity } = req.query;
    res.render('cutbackFruit', { fruit_id, fruit_name, quantity });
});


app.post('/cutbackQuantity', async (req, res) => {
    const { fruit_id, quantity } = req.body;
    const quantityToAdd = parseInt(quantity);

    try {
        const result = await pool.query('SELECT quantity FROM fruit WHERE fruit_id = $1', [fruit_id]);

        if (result.rows.length === 0) {
            return res.status(404).send("ไม่พบข้อมูลผลไม้");
        }

        const currentQuantity = result.rows[0].quantity;
        const newQuantity = currentQuantity - quantityToAdd;

        await pool.query('UPDATE fruit SET quantity = $1 WHERE fruit_id = $2', [newQuantity, fruit_id]);

        res.redirect('/showFruit'); 
    } catch (err) {
        console.error(err);
        res.status(500).send("เกิดข้อผิดพลาดในการอัปเดต");
    }
});

app.get('/showChalendar', async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT 
            a.availability_id,
            a.start_date,
            a.end_date,
            a.quantity,
            f.fruit_name,
            p.start_time,
            p.end_time
            FROM availability a
            JOIN fruit f ON a.fruit_id = f.fruit_id
            JOIN peroid p ON a.peroid_id = p.peroid_id;`
        );

        const availability = result.rows.map(row => {
            const startDate = new Date(row.start_date);
            const endDate = new Date(row.end_date);

            return {
                ...row,
                start_date: `${startDate.getFullYear()}-${startDate.getMonth() + 1}-${startDate.getDate()}`,
                end_date: `${endDate.getFullYear()}-${endDate.getMonth() + 1}-${endDate.getDate()}`
            };
        });

        res.render('showChalendar', { availability });

    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});

app.get('/insertChalendar', async (req, res) => {
    try {
        const fruitResult = await pool.query(`SELECT fruit_id, fruit_name FROM fruit`);
        const peroidResult = await pool.query(`SELECT peroid_id, start_time, end_time FROM peroid`);

        res.render('insertChalendar', { fruit: fruitResult.rows, peroid: peroidResult.rows });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});

    app.post('/insertChalendar', async (req, res) => {
        try {
            const { availability_id, start_date, end_date, quantity, fruit_id, peroid_id } = req.body;

await pool.query(
  `INSERT INTO availability (availability_id, start_date, end_date, quantity, fruit_id, peroid_id)
   VALUES ($1, $2, $3 , $4, $5, $6)`,
  [availability_id, start_date, end_date, quantity, fruit_id, peroid_id]
);

    
            await pool.query(
                `UPDATE fruit
                 SET quantity = quantity - $1
                 WHERE fruit_id = $2`,
                [quantity, fruit_id]
            );
    
            res.redirect('/showChalendar');
        } catch (err) {
            console.error(err);
            res.status(500).send('Server Error');
        }
    });
    



app.get('/showTime', async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT peroid_id, start_time, end_time FROM peroid`
        );

        res.render('showTime', { peroid: result.rows });

    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});

app.get('/insertTime', (req, res) => {
    res.render('insertTime');
});


app.post('/insertTime', async (req, res) => {
    try {
        const { peroid_id ,start_time, end_time} = req.body;
    
        await pool.query(
          `INSERT INTO peroid (peroid_id, start_time, end_time)
           VALUES ($1, $2, $3)`,
          [peroid_id, start_time, end_time]
        );
    
        res.redirect('/showTime');
      } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
      }
});

    app.get('/userPage', async (req, res) => {
        try {
            const fruitResult = await pool.query(`SELECT fruit_id, fruit_name FROM fruit`);
            res.render('userPage', { fruit: fruitResult.rows, publicList});
        
        } catch (err) {
            console.error(err);
            res.status(500).send('Server error');
        }
    });

 app.post('/get-availability', async (req, res) => {
  const { fruit_id } = req.body;
  const query = `
    SELECT a.start_date, a.end_date, a.quantity, p.start_time, p.end_time
    FROM availability a
    JOIN fruit f ON a.fruit_id = f.fruit_id
    JOIN peroid p ON a.peroid_id = p.peroid_id
    WHERE f.fruit_id = $1
  `;

  try {
    const result = await pool.query(query, [fruit_id]);
    res.json(result.rows); 
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
});

app.get('/insertTime', (req, res) => {
    res.render('insertTime');
});

app.get('/fruit/:id', async (req, res) => {
  const fruitId = req.params.id;

  try {
    const result = await pool.query(`
    SELECT
    r.availability_id, 
    f.fruit_name,
    r.quantity,
    r.start_date,
    r.end_date,
    p.start_time,
    p.end_time
    FROM availability r
    JOIN fruit f ON r.fruit_id = f.fruit_id
    JOIN peroid p ON r.peroid_id = p.peroid_id
    WHERE f.fruit_id = $1
    ORDER BY r.start_date
    `, [fruitId]);

    if (result.rows.length === 0) {
      return res.status(404).send('ไม่พบข้อมูลผลไม้');
    }

    const fruitName = result.rows[0].fruit_name;
    res.render('fruitDetail', { fruitName, schedules: result.rows, fruitId });
    
  } catch (err) {
    console.error(err);
    res.status(500).send('เกิดข้อผิดพลาดในเซิร์ฟเวอร์');
  }
});

app.get('/fruit/:id/:date', async (req, res) => {
  const fruitId = req.params.id;
  const [startDate, endDate] = req.params.date.split('&'); // แยกวันที่

  console.log('Start:', startDate);
  console.log('End:', endDate);

  try {
    const result = await pool.query(`
  SELECT
    r.availability_id, 
    f.fruit_name,
    r.quantity,
    r.start_date,
    r.end_date,
    p.start_time,
    p.end_time
  FROM availability r
  JOIN fruit f ON r.fruit_id = f.fruit_id
  JOIN peroid p ON r.peroid_id = p.peroid_id
  WHERE f.fruit_id = $1
    AND r.end_date >= $2
    AND r.start_date <= $3
  ORDER BY r.start_date
`, [fruitId, startDate, endDate]);

    if (result.rows.length === 0) {
      return res.status(404).send('ไม่พบข้อมูลผลไม้ในช่วงวันที่ที่เลือก');
    }

    const fruitName = result.rows[0].fruit_name;
    res.render('fruitDetail', { fruitName, schedules: result.rows, fruitId });
  } catch (err) {
    console.error(err);
    res.status(500).send('เกิดข้อผิดพลาดในเซิร์ฟเวอร์');
  }
});


app.get('/orders', (req, res) => {
  const {
    fruit_id,
    availability_id,
    fruit_name,
    start_date,
    end_date,
    start_time,
    end_time,
    quantity
  } = req.query;

  res.render('orders', {
    fruit_id,availability_id,fruit_name,start_date,end_date,start_time,end_time,quantity});
});

app.post('/orders', async (req, res) => {
        try {
            const { order_id, first_name, last_name, email, phone_number, order_quantity,availability_id,state } = req.body;

            await pool.query(
                `INSERT INTO orders(order_id,first_name, last_name, email, phone_number,order_quantity, availability_id,state)
                 VALUES ($1, $2, $3 , $4, $5, $6, $7, $8)`,
                [order_id, first_name, last_name, email, phone_number,order_quantity, availability_id,state]
            );
    
            await pool.query(
                `UPDATE availability
                 SET quantity = quantity - $1
                 WHERE availability_id = $2`,
                [order_quantity, availability_id]
            );
            
    
            res.redirect('/userPage');
        } catch (err) {
            console.error(err);
            res.status(500).send('Server Error');
        }
    });

    app.get('/manageReserve', async (req, res) => {
        try {
            const result = await pool.query(
            `SELECT 
            o.order_id,
            o.first_name,
            o.last_name,
            o.email,
            o.phone_number,
    		o.order_quantity,
		    a.start_date,
		    a.end_date,
		    f.fruit_name,
            o.state
            FROM orders o
            JOIN availability a ON o.availability_id = a.availability_id
            JOIN fruit f ON a.fruit_id = f.fruit_id;`
            );
            res.render('manageReserve', { orders: result.rows });

        } catch (err) {
            console.error(err);
            res.status(500).send('Server error');
        }
    });

    app.get('/approve/:id', async (req, res) => {
    const order_id = req.params.id;

    try {
        await pool.query(
            'UPDATE orders SET state = $1 WHERE order_id = $2',
            ['approved', order_id]
        );

        
        res.redirect('/manageReserve'); 
    } catch (err) {
        console.error('Error updating status:', err);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/denied/:id', async (req, res) => {
    const order_id = req.params.id;

    try {
        await pool.query(
            'UPDATE orders SET state = $1 WHERE order_id = $2',
            ['denied', order_id]
        );

        
        res.redirect('/manageReserve'); 
    } catch (err) {
        console.error('Error updating status:', err);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/unfulfilled/:id', async (req, res) => {
    const order_id = req.params.id;

    try {
        await pool.query(
            'UPDATE orders SET state = $1 WHERE order_id = $2',
            ['unfulfilled', order_id]
        );

        
        res.redirect('/manageReserve'); 
    } catch (err) {
        console.error('Error updating status:', err);
        res.status(500).send('Internal Server Error');
    }
});


////////////////ข่าว//////////////////

// GET: admin/public
app.get('/public', (req, res) => {
  res.render('admin-public', { publicList });
});

// POST: add
app.post('/admin/public/add', upload.single('image'), (req, res) => {
  const { title, date, content } = req.body;
  const id = Date.now();
  const image = req.file ? '/uploads/' + req.file.filename : null;
  publicList.push({ id, title, date, content, image });
  res.redirect('/public');
});

// POST: edit
app.post('/admin/public/edit/:id', upload.single('image'), (req, res) => {
  const id = parseInt(req.params.id);
  const { title, date, content } = req.body;
  const image = req.file ? '/uploads/' + req.file.filename : null;

  const item = publicList.find(p => p.id === id);
  if (item) {
    item.title = title;
    item.date = date;
    item.content = content;
    if (image) item.image = image;
  }
  res.redirect('/public');
});

// POST: delete
app.post('/admin/public/delete/:id', (req, res) => {
  const id = parseInt(req.params.id);
  publicList = publicList.filter(p => p.id !== id);
  res.redirect('/public');
});

////////////////ข่าว//////////////////


///////////////แก้ไขเวลา///////////////

app.get('/editTime', async (req, res) => {
    try {
        // ดึงข้อมูลทั้งหมดหรือข้อมูลที่ต้องการจากฐานข้อมูล
        const result = await pool.query('SELECT peroid_id, start_time, end_time FROM peroid');

        if (result.rows.length === 0) {
            return res.status(404).send('ไม่พบข้อมูลเวลา');
        }

        // ส่งข้อมูลทั้งหมดไปให้หน้า view
        res.render('editTime', { periods: result.rows });
    } catch (err) {
        console.error(err);
        res.status(500).send('เกิดข้อผิดพลาดในการดึงข้อมูลเวลา');
    }
});


// รับค่าจากฟอร์มและอัปเดตเวลาในฐานข้อมูล
app.post('/updateTime', async (req, res) => {
    const { peroid_id, start_time, end_time } = req.body;

    try {
        // อัปเดตข้อมูลเวลาในฐานข้อมูล
        await pool.query(
            'UPDATE peroid SET start_time = $1, end_time = $2 WHERE peroid_id = $3',
            [start_time, end_time, peroid_id]
        );

        res.redirect('/showTime');
    } catch (err) {
        console.error(err);
        res.status(500).send('เกิดข้อผิดพลาดในการอัปเดตเวลา');
    }
});


///////////////แก้ไขเวลา///////////////
    
app.listen(3000, () => {
    console.log('Server is running on port 3000');
});