const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const multer = require('multer');
const path = require('path');
const { Pool } = require('pg');
const app = express();



app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');



app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use(session({
    secret: 'mySecretKey',
    resave: false,
    saveUninitialized: true,
}));


const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'reserve_fruit',
    password: '1',
    port: 5432,
});

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'public/uploads'); 
    },
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname);
      const name = Date.now() + ext;
      cb(null, name);
    }
  });

  const upload = multer({ storage });

app.get('/', (req, res) => {
    res.render('index');
});

app.get('/showFruit', async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT fruit_id, fruit_name, image_path, quantity FROM fruit`
        );

        res.render('showFruit', { fruit: result.rows });

    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});

app.get('/insertFruit', (req, res) => {
    res.render('insertFruit');
});

app.post('/insertFruit', upload.single('image_path'), async (req, res) => {
    try {
      const { fruit_name, quantity } = req.body;
      const imageFile = req.file ? '/uploads/' + req.file.filename : null;
  
      await pool.query(
        `INSERT INTO fruit (fruit_name, image_path, quantity)
         VALUES ($1, $2, $3)`,
        [fruit_name, imageFile, quantity]
      );
  
      res.redirect('/showFruit');
    } catch (err) {
      console.error(err);
      res.status(500).send('Server Error');
    }
  });

  app.get('/multiplyFruit', (req, res) => {
    const { fruit_id, fruit_name, quantity } = req.query;
    res.render('multiplyFruit', { fruit_id, fruit_name, quantity });
});

app.post('/multiplyQuantity', async (req, res) => {
    const { fruit_id, quantity } = req.body;
    const quantityToAdd = parseInt(quantity);

    try {
        const result = await pool.query('SELECT quantity FROM fruit WHERE fruit_id = $1', [fruit_id]);

        if (result.rows.length === 0) {
            return res.status(404).send("ไม่พบข้อมูลผลไม้");
        }

        const currentQuantity = result.rows[0].quantity;
        const newQuantity = currentQuantity + quantityToAdd;

        await pool.query('UPDATE fruit SET quantity = $1 WHERE fruit_id = $2', [newQuantity, fruit_id]);

        res.redirect('/showFruit'); 
    } catch (err) {
        console.error(err);
        res.status(500).send("เกิดข้อผิดพลาดในการอัปเดต");
    }
});

app.get('/cutbackFruit', (req, res) => {
    const { fruit_id, fruit_name, quantity } = req.query;
    res.render('cutbackFruit', { fruit_id, fruit_name, quantity });
});


app.post('/cutbackQuantity', async (req, res) => {
    const { fruit_id, quantity } = req.body;
    const quantityToAdd = parseInt(quantity);

    try {
        const result = await pool.query('SELECT quantity FROM fruit WHERE fruit_id = $1', [fruit_id]);

        if (result.rows.length === 0) {
            return res.status(404).send("ไม่พบข้อมูลผลไม้");
        }

        const currentQuantity = result.rows[0].quantity;
        const newQuantity = currentQuantity - quantityToAdd;

        await pool.query('UPDATE fruit SET quantity = $1 WHERE fruit_id = $2', [newQuantity, fruit_id]);

        res.redirect('/showFruit'); 
    } catch (err) {
        console.error(err);
        res.status(500).send("เกิดข้อผิดพลาดในการอัปเดต");
    }
});

app.get('/showChalendar', async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT 
            a.id,
            a.start_date,
            a.end_date,
            a.quantity,
            f.fruit_name,
            p.start_time,
            p.end_time
            FROM availability a
            JOIN fruit f ON a.fruit_id = f.fruit_id
            JOIN peroid p ON a.peroid_id = p.peroid_id;`
        );

        // แปลงวันที่ของทุกแถวใน result.rows
        const availability = result.rows.map(row => {
            const startDate = new Date(row.start_date);
            const endDate = new Date(row.end_date);

            return {
                ...row,
                start_date: `${startDate.getFullYear()}-${startDate.getMonth() + 1}-${startDate.getDate()}`,
                end_date: `${endDate.getFullYear()}-${endDate.getMonth() + 1}-${endDate.getDate()}`
            };
        });

        res.render('showChalendar', { availability });

    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});

app.get('/insertChalendar', async (req, res) => {
    try {
        const fruitResult = await pool.query(`SELECT fruit_id, fruit_name FROM fruit`);
        const peroidResult = await pool.query(`SELECT peroid_id, start_time, end_time FROM peroid`);

        res.render('insertChalendar', { fruit: fruitResult.rows, peroid: peroidResult.rows });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});

    app.post('/insertChalendar', async (req, res) => {
        try {
            const { id, start_date, end_date, quantity, fruit_id, peroid_id } = req.body;

            await pool.query(
                `INSERT INTO availability (id, start_date, end_date, quantity, fruit_id, peroid_id)
                 VALUES ($1, $2, $3 , $4, $5, $6)`,
                [id, start_date, end_date, quantity, fruit_id, peroid_id]
            );
    
            await pool.query(
                `UPDATE fruit
                 SET quantity = quantity - $1
                 WHERE fruit_id = $2`,
                [quantity, fruit_id]
            );
    
            res.redirect('/showChalendar');
        } catch (err) {
            console.error(err);
            res.status(500).send('Server Error');
        }
    });
    



app.get('/showTime', async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT peroid_id, start_time, end_time FROM peroid`
        );

        res.render('showTime', { peroid: result.rows });

    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});

app.get('/insertTime', (req, res) => {
    res.render('insertTime');
});


app.post('/insertTime', async (req, res) => {
    try {
        const { peroid_id ,start_time, end_time} = req.body;
    
        await pool.query(
          `INSERT INTO peroid (peroid_id, start_time, end_time)
           VALUES ($1, $2, $3)`,
          [peroid_id, start_time, end_time]
        );
    
        res.redirect('/showTime');
      } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
      }
});

// แสดงหน้าแก้ไขเวลา
app.get('/editTime', async (req, res) => {
    try {
        // ดึงข้อมูลทั้งหมดหรือข้อมูลที่ต้องการจากฐานข้อมูล
        const result = await pool.query('SELECT peroid_id, start_time, end_time FROM peroid');

        if (result.rows.length === 0) {
            return res.status(404).send('ไม่พบข้อมูลเวลา');
        }

        // ส่งข้อมูลทั้งหมดไปให้หน้า view
        res.render('editTime', { periods: result.rows });
    } catch (err) {
        console.error(err);
        res.status(500).send('เกิดข้อผิดพลาดในการดึงข้อมูลเวลา');
    }
});


// รับค่าจากฟอร์มและอัปเดตเวลาในฐานข้อมูล
app.post('/updateTime', async (req, res) => {
    const { peroid_id, start_time, end_time } = req.body;

    try {
        // อัปเดตข้อมูลเวลาในฐานข้อมูล
        await pool.query(
            'UPDATE peroid SET start_time = $1, end_time = $2 WHERE peroid_id = $3',
            [start_time, end_time, peroid_id]
        );

        res.redirect('/showTime');
    } catch (err) {
        console.error(err);
        res.status(500).send('เกิดข้อผิดพลาดในการอัปเดตเวลา');
    }
});


// Route สำหรับอัปเดต availability
app.post('/updateAvailability', async (req, res) => {
    const { start_date, end_date, quantity, fruit_id } = req.body;

    try {
        // UPDATE availability โดยอิง fruit_id และวันที่ (หรือคุณสามารถใช้ id ถ้ามีส่งมาด้วย)
        const updateQuery = `
            UPDATE availability 
            SET start_date = $1, end_date = $2, quantity = $3 
            WHERE fruit_id = $4
        `;

        await pool.query(updateQuery, [start_date, end_date, quantity, fruit_id]);

        res.redirect('/showChalendar');
        
    } catch (err) {
        console.error('Error updating availability:', err);
        res.status(500).send("เกิดข้อผิดพลาดในการอัปเดตข้อมูล");
    }
});


app.get('/updateAvailability', async (req, res) => {
    const fruitResult = await pool.query('SELECT fruit_id, fruit_name FROM fruit');
    res.render('updateAvailability',{fruit: fruitResult.rows});
});

app.get('/Home', async (req, res) => {
     try {
            const fruitResult = await pool.query(`SELECT fruit_id, fruit_name FROM fruit`);
            res.render('Home', { fruit: fruitResult.rows});
        
        } catch (err) {
            console.error(err);
            res.status(500).send('Server error');
        }
    });

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});